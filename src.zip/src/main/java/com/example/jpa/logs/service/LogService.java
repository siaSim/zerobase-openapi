package com.example.jpa.logs.service;


public interface LogService {

    void add(String text);

    void deleteLog();
}
