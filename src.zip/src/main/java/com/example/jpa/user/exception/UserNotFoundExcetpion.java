package com.example.jpa.user.exception;

public class UserNotFoundExcetpion extends RuntimeException {
    public UserNotFoundExcetpion(String s) {
        super(s);
    }
}
